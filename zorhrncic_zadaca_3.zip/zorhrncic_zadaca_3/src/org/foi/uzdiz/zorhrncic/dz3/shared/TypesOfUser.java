/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.uzdiz.zorhrncic.dz3.shared;

/**
 *
 * @author Zoran
 */
public enum TypesOfUser {
  //  0 - staklo, 1 - papir, 2 - metal, 3 - bio, 4 - mješano
    SMALL,
    MEDIUM,
    BIG
}

